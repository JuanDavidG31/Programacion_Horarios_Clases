package co.edu.unbosque.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import co.edu.unbosque.controller.HorarioWsHandler;


@Configuration
@EnableWebSocket
public class WsConfig implements WebSocketConfigurer {

    private final HorarioWsHandler handler;

    public WsConfig(HorarioWsHandler handler) {
        this.handler = handler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(handler, "/ws/horario").setAllowedOrigins("http://localhost:5173");
    }
}
