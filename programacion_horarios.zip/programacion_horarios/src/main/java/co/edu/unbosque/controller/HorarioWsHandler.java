package co.edu.unbosque.controller;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import co.edu.unbosque.model.Resultado;
import co.edu.unbosque.publisher.PublicadorWebSocket;
import co.edu.unbosque.service.ProgramacionService;


@Component
public class HorarioWsHandler extends TextWebSocketHandler {

    private final ProgramacionService servicio;
    private final PublicadorWebSocket publicador;

    public HorarioWsHandler(ProgramacionService servicio, PublicadorWebSocket publicador) {
        this.servicio = servicio;
        this.publicador = publicador;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        publicador.registrar(session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        publicador.retirar(session);
    }

    // formato: MOVER|bloqueId|dia|hora|versionBase
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException {
        String[] p = message.getPayload().split("\\|");
        if (p.length != 5 || !p[0].equals("MOVER")) {
            publicador.enviar(session.getId(), "ERROR|formato");
            return;
        }

        int hora;
        long versionBase;
        try {
            hora = Integer.parseInt(p[3]);
            versionBase = Long.parseLong(p[4]);
        } catch (NumberFormatException e) {
            publicador.enviar(session.getId(), "ERROR|numero");
            return;
        }

        Resultado r = servicio.moverSesion(p[1], versionBase, p[2], hora);
        if (!r.aplicado()) {
            publicador.enviar(session.getId(), PublicadorWebSocket.mensaje("CONFLICTO", p[1], r.bloque()));
        }
    }
}
