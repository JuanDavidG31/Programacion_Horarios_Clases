package co.edu.unbosque.model;

public record Bloque(String dia, int hora, long version) {
}
