package co.edu.unbosque.model;

public record Resultado(boolean aplicado, Bloque bloque) {
}
