package co.edu.unbosque.publisher;

import co.edu.unbosque.model.Bloque;

public interface PublicadorEventos {

    void sesionMovida(String bloqueId, Bloque bloque);
}
