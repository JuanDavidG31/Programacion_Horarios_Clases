package co.edu.unbosque.publisher;


import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;

import co.edu.unbosque.model.Bloque;


@Component
public class PublicadorWebSocket implements PublicadorEventos {

    private static final Logger log = LoggerFactory.getLogger(PublicadorWebSocket.class);

    private final Map<String, WebSocketSession> sesiones = new ConcurrentHashMap<>();

    public void registrar(WebSocketSession session) {
        sesiones.put(session.getId(), new ConcurrentWebSocketSessionDecorator(session, 5000, 64 * 1024));
    }

    public void retirar(WebSocketSession session) {
        sesiones.remove(session.getId());
    }

    public void enviar(String sesionId, String texto) throws IOException {
        WebSocketSession s = sesiones.get(sesionId);
        if (s != null) {
            s.sendMessage(new TextMessage(texto));
        }
    }

    public static String mensaje(String tipo, String bloqueId, Bloque b) {
        return tipo + "|" + bloqueId + "|" + b.dia() + "|" + b.hora() + "|" + b.version();
    }

    @Override
    public void sesionMovida(String bloqueId, Bloque bloque) {
        TextMessage msg = new TextMessage(mensaje("ACTUALIZADO", bloqueId, bloque));
        for (WebSocketSession s : sesiones.values()) {
            try {
                if (s.isOpen()) {
                    s.sendMessage(msg);
                }
            } catch (IOException e) {
                log.warn("No se pudo enviar a la sesion {}", s.getId());
            }
        }
    }
}
