package co.edu.unbosque.repository;

import co.edu.unbosque.model.Resultado;

public interface RepositorioHorario {

    Resultado guardarConVersion(String bloqueId, long versionBase, String dia, int hora);
}
