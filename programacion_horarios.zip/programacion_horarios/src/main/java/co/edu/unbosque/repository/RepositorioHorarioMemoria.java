package co.edu.unbosque.repository;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

import co.edu.unbosque.model.Bloque;
import co.edu.unbosque.model.Resultado;


@Repository
public class RepositorioHorarioMemoria implements RepositorioHorario {

    private final Map<String, Bloque> bloques = new ConcurrentHashMap<>();

    // solo se aplica si la version base es la vigente
    @Override
    public synchronized Resultado guardarConVersion(String bloqueId, long versionBase, String dia, int hora) {
        Bloque actual = bloques.getOrDefault(bloqueId, new Bloque("LUN", 8, 0));
        if (actual.version() != versionBase) {
            return new Resultado(false, actual);
        }
        Bloque nuevo = new Bloque(dia, hora, actual.version() + 1);
        bloques.put(bloqueId, nuevo);
        return new Resultado(true, nuevo);
    }
}
