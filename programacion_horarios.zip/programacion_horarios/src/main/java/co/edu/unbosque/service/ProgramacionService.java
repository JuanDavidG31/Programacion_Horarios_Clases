package co.edu.unbosque.service;

import org.springframework.stereotype.Service;

import co.edu.unbosque.model.Resultado;
import co.edu.unbosque.publisher.PublicadorEventos;
import co.edu.unbosque.repository.RepositorioHorario;


@Service
public class ProgramacionService {

    private final RepositorioHorario repositorio;
    private final PublicadorEventos publicador;

    public ProgramacionService(RepositorioHorario repositorio, PublicadorEventos publicador) {
        this.repositorio = repositorio;
        this.publicador = publicador;
    }

    public Resultado moverSesion(String bloqueId, long versionBase, String dia, int hora) {
        Resultado r = repositorio.guardarConVersion(bloqueId, versionBase, dia, hora);
        if (r.aplicado()) {
            publicador.sesionMovida(bloqueId, r.bloque());
        }
        return r;
    }
}
